<?php
/***************************************************************************
 *                            lang_admin_attach.php [German]
 *                              -------------------
 *     begin                : Thu Feb 07 2002
 *     copyright            : (C) 2002 Meik Sievertsen
 *     email                : acyd.burn@gmx.de
 *
 *     $Id: lang_admin_attach.php,v 2.1.1 2002/03/25 meik Exp $
 *
 ****************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

//
// Attachment Mod Admin Language Variables
//

// Modules, this replaces the keys used
$lang['Attachments'] = "Attachments";
$lang['Attachment'] = "Attachment";

$lang['Extension_control'] = "Bearbeite Erweiterungen";

$lang['Extensions'] = "Erweiterungen";
$lang['Extension'] = "Erweiterung";
$lang['Mimetypes'] = "Mime Types"; 
$lang['Mimetype'] = "Mime Type"; 
$lang['Mimegroups'] = "Mime Gruppen";
$lang['Mimegroup'] = "Mime Gruppe";

// Auth pages
$lang['Attach'] = "Attachments";

// Attachments
$lang['Select_action'] = "W�hle eine Aktion";

// Attachments -> Management
$lang['Manage_attachments_explain'] = "Hier kannst du die Allgemeinen Einstellungen f�r das Attachment Mod konfigurieren.";
$lang['Attach_settings'] = "Attachment Einstellungen";
$lang['Upload_directory'] = "Upload Verzeichnis";
$lang['Attach_img_path'] = "Pfad zu einem Bild f�r Attachments";
$lang['Attach_topic_icon'] = "Attachment Topic Icon";
$lang['Attach_topic_icon_explain'] = "Dieses Bild wird vor einem Topic, in dem Attachments gepostet wurden, angezeigt. Lassen Sie das Feld leer, wenn es nicht angezeigt werden soll.";
$lang['Display_images'] = "Bilder anzeigen";
$lang['Display_images_explain'] = "Anzeigen von Bildern, anstatt bei diesen einen Link zur Datei anzuzeigen.";
$lang['Max_filesize_attach'] = "Dateigr��e";
$lang['Max_filesize_attach_explain'] = "Maximale Dateigr��e f�r Attachments (in Bytes). Ein Wert von 0 bedeutet 'unbegrenzt'.";
$lang['Attach_quota'] = "Attachment Quota";
$lang['Attach_quota_explain'] = "Hier kannst du die maximale Gr��e ALLER Attachments definieren.";
$lang['Max_attachments'] = "Maximale Anzahl an Attachments";
$lang['Max_attachments_explain'] = "Hier kannst du die Anzahl der Attachments, die in einer Nachricht erlaubt sind angeben.";
$lang['Disable_mod'] = "Attachment Mod abschalten";
$lang['Disable_mod_explain'] = "Diese Option ist haupts�chlich zum testen neuer Templates oder Themes gedacht, sie unterbindet alle Attachment Funktionen, au�er diese im Administrationsbereich.";
$lang['Attach_config_updated'] = "Attachment Einstellungen wurden erfolgreich ver�ndert";
$lang['Click_return_attach_config'] = "Klicke %shier%s um zu den Attachment Einstellungen zur�ckzukehren";

// Attachments -> Extension Control
$lang['Manage_forbidden_extensions'] = "Verbotene Erweiterungen einstellen";
$lang['Manage_forbidden_extensions_explain'] = "Hier kannst du verbotene Erweiterungen hinzuf�gen oder l�schen. Die Erweiterungen php, php3 und php4 sind standardm��ig verboten, du kannst sie hier nicht l�schen.";
$lang['Extension_exist'] = "Erweiterung %s existiert bereits."; // replace %s with the extension

// Attachments -> Mime Types
$lang['Manage_mime_types'] = "Mime Types verwalten";
$lang['Manage_mime_types_explain'] = "Hier kannst du deine Mime Types konfigurieren. Wenn du einen mime type erlauben/verbieten m�chtest, dann benutze bitte die Mime Gruppen Einstellungen.";
$lang['Explanation'] = "Erkl�rung";
$lang['Invalid_mimetype'] = "Ung�ltiger Mime Type";
$lang['Mimetype_exist'] = "Mime Type %s existiert bereits"; // replace %s with the mimetype

// Attachments -> Mime Groups
$lang['Manage_mime_groups'] = "Mime Groups verwalten";
$lang['Manage_mime_groups_explain'] = "Hier kannst du deine Mime Groups konfigurieren. Du kannst Mime Groups verbieten und eine Image Group zuweisen.";
$lang['Image_group'] = "Image Group";
$lang['Allowed'] = "Erlaubt";
$lang['Mimegroup_exist'] = "Mime Group %s existiert bereits"; // replace %s with the mimetype
$lang['Special_category'] = "Spezial Kategorie";
$lang['Category_images'] = "bilder";
$lang['Category_wma_files'] = "wma-dateien";
$lang['Category_swf_files'] = "flash-dateien";

$lang['Download_mode'] = "Download Modus";
$lang['Upload_image'] = "Attachment Bild";
$lang['Max_filesize'] = "Maximale Dateigr��e";

$lang['Collapse'] = "Aufklappen";
$lang['Decollapse'] = "Zuklappen";

// Attachments -> Shadow Attachments
$lang['Shadow_attachments'] = "'Versteckte' Attachments";		// used in modules-list
$lang['Shadow_attachments_title'] = "'Versteckte' Attachments";
$lang['Shadow_attachments_explain'] = "Hier kannst du die Attachments l�schen, die einer Nachricht zugeordnet sind aber nicht mehr existieren und die Dateien, die zwar existieren aber in keiner Nachricht auftauchen. Du kannst dir die existierenden Dateien angucken oder herunterladen wenn du auf diese klickst. Wenn kein Link existiert, dann gibt es diese Datei auch nicht mehr im Dateisystem.";
$lang['Shadow_attachments_file_explain'] = "Alle Attachments l�schen die im Dateisystem verblieben sind aber keiner Nachricht zugeordnet werden kann.";
$lang['Shadow_attachments_row_explain'] = "Alle Attachments Informationen l�schen die auf nicht vorhandene Attachments im Dateisystem verweisen.";

// Attachments -> Control Panel
$lang['Control_Panel'] = "Kontrollzentrum";
$lang['Control_panel_title'] = "File Attachments Kontrollzentrum";
$lang['Control_panel_explain'] = "Hier kannst du Attachments, basierend auf Benutzername, Attachments, Mime Gruppen usw. verwalten und angucken.";

$lang['File_comment_cp'] = "Kommentar";

// Sort Types
$lang['Sort_Attachments'] = "Attachments";
$lang['Sort_Size'] = "Gr��e";
$lang['Sort_Filename'] = "Dateiname";
$lang['Sort_Comment'] = "Kommentar";
$lang['Sort_Mimegroup'] = "Mime Gruppe";
$lang['Sort_Mimetype'] = "Mime Typ";
$lang['Sort_Downloads'] = "Downloads";
$lang['Sort_Posttime'] = "Postzeit";
$lang['Sort_Posts'] = "Posts";

// View Types
$lang['View_Statistic'] = "Statistik";
$lang['View_Search'] = "Suche";
$lang['View_Username'] = "Benutzername";
$lang['View_Attachments'] = "Attachments";

// Control Panel -> Statistics
$lang['Number_of_attachments'] = "Anzahl an Attachments";
$lang['Total_filesize'] = "komplette Dateigr��e";
$lang['Number_posts_attach'] = "Anzahl der Posts mit Attachments";
$lang['Number_topics_attach'] = "Anzahl der Topics mit Attachments";
$lang['Number_users_attach'] = "Anzahl der User die Attachments gepostet haben";

// Control Panel -> Search
$lang['Search_wildcard_explain'] = "Benutze das *-Zeichen als Joker";
$lang['Size_smaller_than'] = "Attachmentgr��e kleiner als (bytes)";
$lang['Size_greater_than'] = "Attachmentgr��e gr��er als (bytes)";
$lang['Count_smaller_than'] = "Anzahl der Downloads ist kleiner als";
$lang['Count_greater_than'] = "Anzahl der Downloads ist gr��er als";
$lang['More_days_old'] = "Mehr als diese Anzahl an Tagen alt";
$lang['No_attach_search_match'] = "Keine Attachments gefunden die den Suchkriterien entsprechen.";

// Control Panel -> Attachments
$lang['Statistics_for_user'] = "Attachment Statistik f�r %s"; // replace %s with username
$lang['Size_in_kb'] = "Gr��e (KB)";
$lang['Downloads'] = "Downloads";
$lang['Post_time'] = "Postzeit";
$lang['Posted_in_topic'] = "Im Topic gepostet";
$lang['Confirm_delete_attachments'] = "Bist du sicher, da� du die ausgew�hlten Attachments l�schen m�chtest";
$lang['Deleted_attachments'] = "Die ausgew�hlten Attachments wurden gel�scht";
$lang['Error_deleted_attachments'] = "Das Attachment konnte nicht gel�scht werden";

?>