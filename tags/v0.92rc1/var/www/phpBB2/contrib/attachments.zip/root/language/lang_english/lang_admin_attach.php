<?php
/***************************************************************************
 *                            lang_admin_attach.php [English]
 *                              -------------------
 *     begin                : Thu Feb 07 2002
 *     copyright            : (C) 2002 Meik Sievertsen
 *     email                : acyd.burn@gmx.de
 *
 *     $Id: lang_admin_attach.php,v 2.1.1 2002/03/25 meik Exp $
 *
 ****************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

//
// Attachment Mod Admin Language Variables
//

// Modules, this replaces the keys used
$lang['Attachments'] = "Attachments";
$lang['Attachment'] = "Attachment";

$lang['Extension_control'] = "Extension Control";

$lang['Extensions'] = "Extension";
$lang['Extension'] = "Extension";
$lang['Mimetypes'] = "Mime Types"; 
$lang['Mimetype'] = "Mime Type"; 
$lang['Mimegroups'] = "Mime Groups";
$lang['Mimegroup'] = "Mime Group";

// Auth pages
$lang['Attach'] = "Attachments";

// Attachments
$lang['Select_action'] = "Select an Action";

// Attachments -> Management
$lang['Manage_attachments_explain'] = "Here you can configure the main settings for the Attachment Mod.";
$lang['Attach_settings'] = "Attachment Settings";
$lang['Upload_directory'] = "Upload Directory";
$lang['Attach_img_path'] = "Path to an image for attachments";
$lang['Attach_topic_icon'] = "Attachment Topic Icon";
$lang['Attach_topic_icon_explain'] = "This Image is displayed before an topic in which attachments posted. Leave this field empty if you don't want it to be displayed.";
$lang['Display_images'] = "Display Images";
$lang['Display_images_explain'] = "Display uploaded Images instead of presenting them as a link";
$lang['Max_filesize_attach'] = "Filesize";
$lang['Max_filesize_attach_explain'] = "Maximum Filesize for Attachments (in Bytes). A value of 0 means 'unlimited'.";
$lang['Attach_quota'] = "Attachment Quota";
$lang['Attach_quota_explain'] = "Here you can define the maximum filesize of ALL Attachments.";
$lang['Max_attachments'] = "Maximum number of Attachments";
$lang['Max_attachments_explain'] = "Here you can enter the maximum number of attachments allowed in one post.";
$lang['Disable_mod'] = "Disable Attachment Mod";
$lang['Disable_mod_explain'] = "This option is mainly for testing new templates or themes, it disables all attachment functions except the Admin Panel.";
$lang['Attach_config_updated'] = "Attachment Configuration Updated Successfully";
$lang['Click_return_attach_config'] = "Click %sHere%s to return to Attachment Configuration";

// Attachments -> Extension Control
$lang['Manage_forbidden_extensions'] = "Manage Forbidden Extensions";
$lang['Manage_forbidden_extensions_explain'] = "Here you can add or delete the forbidden extensions. The Extensions php, php3 and php4 are disallowed by default, you can not delete them.";
$lang['Extension_exist'] = "Extension %s already exist"; // replace %s with the extension

// Attachments -> Mime Types
$lang['Manage_mime_types'] = "Manage Mime Types";
$lang['Manage_mime_types_explain'] = "Here you can manage your mime types. If you want to allow/disallow a mime type, please use the mime group management.";
$lang['Explanation'] = "Explanation";
$lang['Invalid_mimetype'] = "Invalid Mime Type";
$lang['Mimetype_exist'] = "Mime Type %s already exist"; // replace %s with the mimetype

// Attachments -> Mime Groups
$lang['Manage_mime_groups'] = "Manage Mime Groups";
$lang['Manage_mime_groups_explain'] = "Here you can add, delete and modify your mime groups, you can disallow mime groups and assign a image group.";
$lang['Image_group'] = "Image Group";
$lang['Allowed'] = "Allowed";
$lang['Mimegroup_exist'] = "Mime Group %s already exist"; // replace %s with the mimetype
$lang['Special_category'] = "Special Category";
$lang['Category_images'] = "images";
$lang['Category_wma_files'] = "wma files";
$lang['Category_swf_files'] = "flash files";

$lang['Download_mode'] = "Download Mode";
$lang['Upload_image'] = "Upload Image";
$lang['Max_filesize'] = "Maximum Filesize";

$lang['Collapse'] = "Collapse";
$lang['Decollapse'] = "Decollapse";

// Attachments -> Shadow Attachments
$lang['Shadow_attachments'] = "Shadow Attachments";		// used in modules-list
$lang['Shadow_attachments_title'] = "Shadow Attachments";
$lang['Shadow_attachments_explain'] = "Here you can delete those attachments assigned to a post but no longer exist on your filesystem, and those files which exist on your filesystem but not assigned to any existing post. You can download or view a file if you click on it, if no link is present, the file does not exist.";
$lang['Shadow_attachments_file_explain'] = "Delete all Attachments that resist on your file system and are not assigned to an existing post.";
$lang['Shadow_attachments_row_explain'] = "Delete all attachment informations for attachments that don't exist on your file space.";

// Attachments -> Control Panel
$lang['Control_Panel'] = "Control Panel";
$lang['Control_panel_title'] = "File Attachment Control Panel";
$lang['Control_panel_explain'] = "Here you can view and manage all Attachments based on Users, Attachments, Views etc...";

$lang['File_comment_cp'] = "File Comment";

// Sort Types
$lang['Sort_Attachments'] = "Attachments";
$lang['Sort_Size'] = "Size";
$lang['Sort_Filename'] = "Filename";
$lang['Sort_Comment'] = "Comment";
$lang['Sort_Mimegroup'] = "Mimegroup";
$lang['Sort_Mimetype'] = "Mimetype";
$lang['Sort_Downloads'] = "Downloads";
$lang['Sort_Posttime'] = "Post Time";
$lang['Sort_Posts'] = "Posts";

// View Types
$lang['View_Statistic'] = "Statistic";
$lang['View_Search'] = "Search";
$lang['View_Username'] = "Username";
$lang['View_Attachments'] = "Attachments";

// Control Panel -> Statistics
$lang['Number_of_attachments'] = "Number of Attachments";
$lang['Total_filesize'] = "Total Filesize";
$lang['Number_posts_attach'] = "Number of Posts with Attachments";
$lang['Number_topics_attach'] = "Number of Topics with Attachments";
$lang['Number_users_attach'] = "Independent Users Posted Attachments";

// Control Panel -> Search
$lang['Search_wildcard_explain'] = "Use * as a wildcard for partial matches";
$lang['Size_smaller_than'] = "Attachment size smaller than (bytes)";
$lang['Size_greater_than'] = "Attachment size greater than (bytes)";
$lang['Count_smaller_than'] = "Download count is smaller than";
$lang['Count_greater_than'] = "Download count is greater than";
$lang['More_days_old'] = "More than this many days old";
$lang['No_attach_search_match'] = "No Attachments met your search criteria";

// Control Panel -> Attachments
$lang['Statistics_for_user'] = "Attachment Statistics for %s"; // replace %s with username
$lang['Size_in_kb'] = "Size (KB)";
$lang['Downloads'] = "Downloads";
$lang['Post_time'] = "Post Time";
$lang['Posted_in_topic'] = "Posted in Topic";
$lang['Confirm_delete_attachments'] = "Are you sure you want to delete the selected attachments";
$lang['Deleted_attachments'] = "The selected Attachments have been deleted";
$lang['Error_deleted_attachments'] = "Can't delete Attachments";

?>