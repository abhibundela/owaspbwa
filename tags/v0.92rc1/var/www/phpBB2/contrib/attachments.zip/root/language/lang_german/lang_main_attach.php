<?php
/***************************************************************************
 *                            lang_main_attach.php [German]
 *                              -------------------
 *     begin                : Thu Feb 07 2002
 *     copyright            : (C) 2002 Meik Sievertsen
 *     email                : acyd.burn@gmx.de
 *
 *     $Id: lang_main_attach.php,v 2.1.1 2002/03/25 meik Exp $
 *
 ****************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

//
// Attachment Mod Main Language Variables
//

// Viewforum
$lang['Rules_attach_can'] = "Du <b>darfst</b> Dateien in diesem Forum posten";
$lang['Rules_attach_cannot'] = "Du darfst <b>keine</b> Dateien in diesem Forum posten";

// Viewtopic
$lang['Mime_type_disallowed_post'] = "Mime Type %s wurde von einem Board-Admin deaktiviert, deshalb ist hier kein Attachment zu sehen"; // used in Posts, replace %s with mime type

// Posting/Replying (Not private messaging!)
$lang['Disallowed_extension'] = "Die Erweiterung %s ist hier verboten"; // replace %s with extension (e.g. .php) 
$lang['Disallowed_Mime_Type'] = "Ein nicht erlaubter Mime Type: %s<p>Erlaubte Formate:<br />%s"; // mime type, allowed types 
$lang['Attachment_too_big'] = "Das Attachment ist zu gro�.<br />Maximale Gr��e: %d %s"; // replace %d with maximum file size, %s with size var
$lang['Attachment_php_size_overrun'] = "Das Attachment ist zu gro�.<br />Vorgegebene Maximale Gr��e in der php.ini: %d MB"; // replace %d with ini_get('upload_max_filesize')
$lang['Invalid_filename'] = "%s ist ein ung�ltiger Dateiname"; // replace %s with given filename
$lang['General_upload_error'] = "Upload Error: Kann das Attachment %s nicht hochladen."; // replace %s with local path 
   
$lang['Add_attachment'] = "Attachment hinzuf�gen";
$lang['Add_attachment_title'] = "Attachment hinzuf�gen";
$lang['Add_attachment_explain'] = "Wenn du kein Attachment hinzuf�gen m�chtest lasse die Felder einfach leer";
$lang['File_name'] = "Dateiname";
$lang['File_comment'] = "Kommentar";
$lang['Delete_attachments'] = "Attachments l�schen";
$lang['Delete_attachment'] = "Attachment l�schen";
$lang['Posted_attachments'] = "gepostete Attachments";
$lang['Update_comment'] = "Kommentar aktualisieren";

// Auth related entries
$lang['Sorry_auth_attach'] = "Entschuldigung, aber nur %s kann in diesem Forum Attachments posten";

// Download Count functionality
$lang['Download_number'] = "Datei wurde insgesamt %d mal heruntergeladen"; // replace %d with count

// Errors at posting
$lang['No_file_comment_available'] = "Kein Datei-Kommentar verf�gbar";
$lang['Too_many_attachments'] = "Attachment kann nicht hinzugef�gt werden, da die maximale Anzahl von %d Attachments in dieser Nachricht erreicht wurde"; // replace %d with maximum number of attachments
$lang['Attach_quota_reached'] = "Entschuldingung, aber die maximale Gr��e aller Attachments wurde erreicht. Bitte kontaktiere den Board Administrator wenn du Fragen hast.";

// Errors at download
$lang['Sorry_auth_view_attach'] = "Entschuldigung, aber du bist nicht autorisiert dieses Attachment anzugucken oder herunterzuladen.";
$lang['Error_no_attachment'] = "Das ausgew�hlte Attachment existiert leider nicht mehr";
$lang['No_attachment_selected'] = "Du hast kein Attachment zum Download oder Betrachten angegeben.";
$lang['Attachment_feature_disabled'] = "Das Attachment Feature ist abgeschaltet.";

// Errors on Upload Directory
// replace %s with directory
$lang['Directory_does_not_exist'] = "Das Verzeichnis '%s' existiert nicht oder kann nicht gefunden werden.";
$lang['Directory_is_not_a_dir'] = "Bitte pr�fe ob '%s' ein Verzeichnis ist."; 
$lang['Directory_not_writeable'] = "Das Verzeichnis '%s' ist nicht schreibbar. Du musst das Upload Verzeichnis erstellen und zu 777 chmodden (oder den Besitzer des Verzeichnisses auf den Besitzer des HTTP-Servers stellen) um Dateien hochladen zu k�nnen.<br />Wenn du nur FTP-Zugriff, �ndere das 'Attribut' des Verzeichnisses auf rwxrwxrwx.";

// Size related Variables
$lang['Bytes'] = "Bytes";
$lang['KB'] = "KB";
$lang['MB'] = "MB";

$lang['Attach_search_query'] = "Suche Attachments";

?>