<?php
/***************************************************************************
 *                            lang_main_attach.php [English]
 *                              -------------------
 *     begin                : Thu Feb 07 2002
 *     copyright            : (C) 2002 Meik Sievertsen
 *     email                : acyd.burn@gmx.de
 *
 *     $Id: lang_main_attach.php,v 2.1.1 2002/03/22 meik Exp $
 *
 ****************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

//
// Attachment Mod Main Language Variables
//

// Viewforum
$lang['Rules_attach_can'] = "You <b>can</b> attach files in this forum";
$lang['Rules_attach_cannot'] = "You <b>cannot</b> attach files in this forum";

// Viewtopic
$lang['Mime_type_disallowed_post'] = "mime type %s was deactivated by an board admin, therefore this attachment is not displayed"; // used in Posts, replace %s with mime type

// Posting/Replying (Not private messaging!)
$lang['Disallowed_extension'] = "The extension %s is not allowed"; // replace %s with extension (e.g. .php) 
$lang['Disallowed_Mime_Type'] = "Not an allowed Mime Type: %s<p>Allowed Types are:<br />%s"; // mime type, allowed types 
$lang['Attachment_too_big'] = "The Attachment is too big.<br />Max Size: %d %s"; // replace %d with maximum file size, %s with size var
$lang['Attachment_php_size_overrun'] = "The Attachment is too big.<br />Max Defined Size in PHP: %d MB"; // replace %d with ini_get('upload_max_filesize')
$lang['Invalid_filename'] = "%s is an invalid filename"; // replace %s with given filename
$lang['General_upload_error'] = "Upload Error: Can't upload Attachment to %s"; // replace %s with local path 
   
$lang['Add_attachment'] = "Add Attachment";
$lang['Add_attachment_title'] = "Add an Attachment";
$lang['Add_attachment_explain'] = "If you do not want to add an attachment to your post leave the fields blank";
$lang['File_name'] = "Filename";
$lang['File_comment'] = "File Comment";
$lang['Delete_attachments'] = "Delete Attachments";
$lang['Delete_attachment'] = "Delete Attachment";
$lang['Posted_attachments'] = "Posted Attachments";
$lang['Update_comment'] = "Update Comment";

// Auth related entries
$lang['Sorry_auth_attach'] = "Sorry but only %s can add attachments to this forum";

// Download Count functionality
$lang['Download_number'] = "File downloaded or viewed %d time(s)"; // replace %d with count

// Errors at posting
$lang['Sorry_auth_view_attach'] = "Sorry but you are not authorized to view or download this attachment";
$lang['No_file_comment_available'] = "No File Comment available";
$lang['Too_many_attachments'] = "Attachment cannot be added, since the max. number of %d Attachments in this post was achieved"; // replace %d with maximum number of attachments
$lang['Attach_quota_reached'] = "Sorry, but the maximum filesize for all Attachments is reached. Please contact the Board Administrator if you have questions.";

// Errors at download
$lang['Error_no_attachment'] = "The selected Attachment does not exist anymore";
$lang['No_attachment_selected'] = "You haven't selected an attachment to download or view.";
$lang['Attachment_feature_disabled'] = "The Attachment Feature is disabled.";

// Errors on Upload Directory
// replace %s with directory
$lang['Directory_does_not_exist'] = "The Directory '%s' does not exist or couldn't be found.";
$lang['Directory_is_not_a_dir'] = "Please check if '%s' is a directory."; 
$lang['Directory_not_writeable'] = "Directory '%s' is not writeable. You'll have to create the upload path and chmod it to 777 (or change the owner to you httpd-servers owner) to upload files.<br />If you have only plain ftp-access change the 'Attribute' of the directory to rwxrwxrwx.";

// Size related Variables
$lang['Bytes'] = "Bytes";
$lang['KB'] = "KB";
$lang['MB'] = "MB";

$lang['Attach_search_query'] = "Search Attachments";

?>