Installation Instructions:

WITH VERSION 2.1.1 OF THE ATTACHMENT MOD ONLY PHPBB2 RC4 AND GREATER ARE SUPPORTED.
PLEASE UPGRADE TO VERSION 2.1.0 IF YOU ARE USING A VERSION PRIOR TO 2.1.0...

if you are using phpBB2 RC-2: Upgrade to the latest version, at least RC-4 ;)

if you are using phpBB2 RC-3: Upgrade to the latest version, at least RC-4 ;)

if you are using phpBB2 RC-4, FINAL or CVS: Please read docs/INSTALL.txt

Upgrading Instructions:

Please read the Instructions in docs/update. For example, if you
are using version 2.1.0 of the Attachment Mod, read the following
documents:
docs/upgrade/update_210_to_211.txt
