<?
//
// update_210_to_211.php
//

//
// This File adds new variables to the Database
//

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path.'extension.inc');
include($phpbb_root_path.'common.'.$phpEx);	
	
//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//

if( !$userdata['session_logged_in'] )
{
	header("Location: " . append_sid("./login." . $phpEx));
}

if( $userdata['user_level'] != ADMIN )
{
	message_die(GENERAL_MESSAGE, $lang['Not_Authorised']);
}

function query($sql, $errormsg)
{
	global $db;

	if ( !($result = $db->sql_query($sql)) )
	{
		print "<br><font color=\"red\">\n";
		print "$errormsg<br>";

		$sql_error = $db->sql_error();
		print $sql_error['code'] .": ". $sql_error['message']. "<br>\n";

		print "<pre>$sql</pre>";
		print "</font>\n";

		return FALSE;
	}
	else
	{
		return $result;
	}
}

$attach_config = array();

$sql = "SELECT *
FROM " . ATTACH_CONFIG_TABLE;

if(!$result = $db->sql_query($sql))
{
	message_die(GENERAL_ERROR, "Could not query attachment information", "", __LINE__, __FILE__, $sql);
}

while ($row = $db->sql_fetchrow($result))
{
	$attach_config[$row['config_name']] = $row['config_value'];
}

echo "<html>";
echo "<body>";
//
// Add three new rows and change one row in attachment types table
//
echo "insert new rows (download_mode, upload_image and max_filesize) to attachment types and change the name if is_image to category...";
$sql = "ALTER TABLE " . ATTACH_TYPES_TABLE . " ADD download_mode TINYINT(1) UNSIGNED DEFAULT '1' NOT NULL";
query($sql, "Couldn't update attachment types table");

$sql = "ALTER TABLE " . ATTACH_TYPES_TABLE . " ADD upload_image VARCHAR(100)";
query($sql, "Couldn't update attachment types table");

$sql = "ALTER TABLE " . ATTACH_TYPES_TABLE . " ADD max_filesize INT(20) DEFAULT '0' NOT NULL";
query($sql, "Couldn't update attachment types table");

$sql = "ALTER TABLE " . ATTACH_TYPES_TABLE . " CHANGE is_image category TINYINT(2) DEFAULT '0' NOT NULL";
query($sql, "Couldn't change value in attachment types table");
echo "done<br />";

//
// Delete Config Variable
//
echo "delete attach config variable image_upload...";
$sql = "DELETE FROM " . ATTACH_CONFIG_TABLE . " WHERE config_name = 'image_upload'";
query($sql, "Couldn't delete config value image_upload");
echo "done<br />";

echo "<br />updated tables structure to 2.1.1 done<br /> Please don't forget to read the update_210_to_211.txt<br />";

?>