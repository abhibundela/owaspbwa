This is a mod, that gives every post some "cards", these cards can be used by those userser who have priveliges to do so 
admin can specify per forum who have rigths to do what, same way as all other privellegies 

in this current version there is 4 types of cards that can be given 

RED - Ban the user imidiatly 
YELLOW - Give the users a warning, and if the total of warning is more than a limit, then ban the user 
GREEN - Reactivate the user 
BLUE - repport post to moderators 

features: 
Max number of warnings before users are banned (board config) 
number of blue cards before Moderators are to be notifyed (board config) 
Intervall Moderators are to be notifyed about blue cards (board config) 
Induvidualy modifying of user's warning numbers (user profile) 
Assigning ban rigth's per forum (forum permissions) 
Assigning unban rigth's per forum (forum permissions) 
Assigning repport post rigth's per forum (forum permissions) 

Every time there is pressed a "Card" some sort of email is sendt out 
but since blue card is normaly assigned to registerd users, I have made it so that admin can specify when the first email is send and in witch intervall further emails are to be sendt (only for blue cards) 
this was requested to avoid moderators geting to meny repports 

this mod consist of 2 parts 
the admin part must be installed as the first (PART 1) and after that the user part (PART 2) 